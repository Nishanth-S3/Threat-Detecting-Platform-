import os
import threading
import requests
import pandas as pd
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import streamlit as st

# Load environment variables from api.env
load_dotenv("api.env")

# VirusTotal API Key
VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "42dab60b89eb612f129d65396c51b0848265cfe519428a4faa4a8ae27d38e820")

# Flask Backend Setup
app = Flask(__name__)  # Corrected this line
CORS(app)

# CSV file to store user details
USER_DATA_FILE = "user_data.csv"

# Ensure the user data file exists
if not os.path.exists(USER_DATA_FILE):
    pd.DataFrame(columns=["username", "password", "email"]).to_csv(USER_DATA_FILE, index=False)

@app.route('/analyze-url', methods=['POST'])
def analyze_url():
    """Analyze a URL using the VirusTotal API."""
    data = request.json
    url_to_check = data.get('url')

    if not url_to_check:
        return jsonify({"error": "No URL provided"}), 400

    # VirusTotal API Endpoint
    vt_endpoint = f"https://www.virustotal.com/api/v3/urls"
    headers = {"x-apikey": VIRUSTOTAL_API_KEY}

    try:
        response = requests.post(vt_endpoint, headers=headers, data={"url": url_to_check})
        if response.status_code == 200:
            # Retrieve the analysis ID
            analysis_data = response.json()
            analysis_id = analysis_data.get('data', {}).get('id', '')

            # Fetch detailed results
            result_endpoint = f"https://www.virustotal.com/api/v3/analyses/{analysis_id}"
            result_response = requests.get(result_endpoint, headers=headers)

            if result_response.status_code == 200:
                analysis_results = result_response.json()
                threats_count = len([  # Counting the malicious and phishing threats
                    item for item in analysis_results.get("data", {}).get("attributes", {}).get("results", {}).values()
                    if item.get("category") in ("malicious", "phishing")
                ])
                analysis_results["threats_count"] = threats_count
                return jsonify(analysis_results), 200
            else:
                return jsonify({"error": "Failed to fetch analysis results"}), 500
        else:
            return jsonify({"error": "Failed to analyze URL"}), response.status_code
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Streamlit Frontend
def run_streamlit():
    # Pages
    st.title("Threat Detection Platform")
    page = st.sidebar.selectbox("Choose Page", ["Sign Up", "Log In", "Threat Detection"])

    if page == "Sign Up":
        st.subheader("Sign Up")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        email = st.text_input("Email")
        if st.button("Sign Up"):
            if username and password and email:
                # Save user data to CSV
                user_data = pd.read_csv(USER_DATA_FILE)
                if username in user_data["username"].values:
                    st.error("Username already exists!")
                else:
                    new_user = pd.DataFrame([{"username": username, "password": password, "email": email}])
                    user_data = pd.concat([user_data, new_user], ignore_index=True)
                    user_data.to_csv(USER_DATA_FILE, index=False)
                    st.success("Sign up successful! Please log in.")
            else:
                st.error("All fields are required.")

    elif page == "Log In":
        st.subheader("Log In")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        if st.button("Log In"):
            if username and password:
                # Verify user data from CSV
                user_data = pd.read_csv(USER_DATA_FILE)
                if (user_data["username"] == username).any() and (user_data["password"] == password).any():
                    st.success("Login successful!")
                    st.session_state["logged_in"] = True
                    st.session_state["username"] = username
                else:
                    st.error("Invalid username or password.")
            else:
                st.error("Both fields are required.")

    elif page == "Threat Detection":
        if "logged_in" not in st.session_state or not st.session_state["logged_in"]:
            st.error("You must log in first!")
        else:
            st.subheader("Threat Detection")
            st.write("Welcome, ", st.session_state["username"])
            url = st.text_input("Enter URL", placeholder="https://example.com")
            if st.button("Check URL"):
                if not url:
                    st.error("Please enter a URL.")
                else:
                    try:
                        # Make a request to the backend
                        response = requests.post(
                            "http://127.0.0.1:5000/analyze-url", json={"url": url}
                        )
                        if response.status_code == 200:
                            data = response.json()
                            threats_count = data.get("threats_count", 0)
                            st.success(f"Threat Analysis Completed!")
                            st.json(data)  # Display full analysis data
                        else:
                            st.error(f"Error: {response.json().get('error', 'Unknown error')}")
                    except Exception as e:
                        st.error(f"Could not connect to the backend: {e}")

# Run Flask and Streamlit
if __name__ == "__main__":  # Corrected this line
    # Start Flask in a separate thread
    threading.Thread(target=lambda: app.run(debug=False, use_reloader=False)).start()

    # Run Streamlit frontend
    run_streamlit()
